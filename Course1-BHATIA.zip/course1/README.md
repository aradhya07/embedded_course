Hey reader!

Just to let you know!

By default,

COURSE1 flag is kept on in the Makefile and the VERBOSE flag has been kept off.

Incase, you want to alternate either of them, kindly proceed as follows:

make build PLATFORM=HOST VERBOSE=enable COURSE1=disable



You can use either of the flags at a time or both as well.

Happy Checking!
Aradhya Bhatia
